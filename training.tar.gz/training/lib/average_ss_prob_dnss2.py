# -*- coding: utf-8 -*-
"""
Created on Wed Feb 22 21:47:26 2017

@author: Jie Hou
"""
import sys
import os
import platform
from Custom_class import remove_1d_padding
from Model_construct import DeepCov_SS_with_paras
from keras.models import model_from_json
import numpy as np
import time
import shutil
import shlex, subprocess
from subprocess import Popen, PIPE

import tensorflow as tf
config = tf.ConfigProto(allow_soft_placement = True)
tf.GPUOptions(per_process_gpu_memory_fraction = 0.4)
config.gpu_options.allow_growth = True
sess= tf.Session(config = config)

def chkdirs(fn):
  dn = os.path.dirname(fn)
  if not os.path.exists(dn): os.makedirs(dn)

def chkfiles(fn):
  if os.path.exists(fn):
    return True 
  else:
    return False

if len(sys.argv) != 7:
          print 'please input the right parameters'
          sys.exit(1)
current_os_name = platform.platform()
print '%s' % current_os_name
if current_os_name == 'Linux-4.15.0-36-generic-x86_64-with-Ubuntu-18.04-bionic': #on local
  GLOBAL_PATH='/mnt/data/zhiye/Python/DNSS2'
elif current_os_name == 'Linux-3.10.0-862.14.4.el7.x86_64-x86_64-with-centos-7.5.1804-Core': #on lewis
  GLOBAL_PATH=os.path.dirname(os.path.dirname(__file__))
  print GLOBAL_PATH
  # GLOBAL_PATH='/storage/hpc/scratch/zggc9/DNSS2'
else:
  print 'Please check current operate system!'
  sys.exit(1)
sys.path.insert(0, GLOBAL_PATH+'/lib/')

test_list=(sys.argv[1]) 
model_list=(sys.argv[2]) 
network_pred_dir=sys.argv[3]
CV_dir=sys.argv[4]
model_prefix=(sys.argv[5])
tag=(sys.argv[6])


## start evaluate the dataset
sequence_file=open(test_list,'r').readlines() 
predir = CV_dir + '/test_prediction/'
chkdirs(predir)
dnssdir = CV_dir + '/test_prediction_dnss/'
chkdirs(dnssdir)
eva_dir = CV_dir + '/test_prediction_q3_sov_log_loss/'
chkdirs(eva_dir)


#perl /storage/htc/bdm/Collaboration/Zhiye/SSP/DNSS2/paper_dataset/State1_Nets_On_OldFea/lib/average_ss_prob_by_list.pl   /storage/htc/bdm/Collaboration/Zhiye/SSP/DNSS2/datasets/new20181005/adj_dncon-train.lst /storage/htc/bdm/Collaboration/Zhiye/SSP/DNSS2/paper_dataset/State1_Nets_On_OldFea/emsemble/model_test.list  /storage/htc/bdm/Collaboration/Zhiye/SSP/DNSS2/paper_dataset/State1_Nets_On_OldFea/outputs/ensemble_out/old/ /storage/htc/bdm/Collaboration/Zhiye/SSP/DNSS2/paper_dataset/State1_Nets_On_OldFea/outputs/ensemble_out/old/avg_out

args_str ="perl /storage/htc/bdm/Collaboration/Zhiye/SSP/DNSS2/paper_dataset/State1_Nets_On_OldFea/lib/average_ss_prob_by_list.pl " +   test_list + " " + model_list + " " + network_pred_dir + " " +predir+ " " +tag
args = shlex.split(args_str)
pipe = subprocess.Popen(args, stdin=subprocess.PIPE)

checkfile=predir+'/'+tag+'_average.done'

time.sleep(10) 
found = 0
while (found == 0):
    print "Checking file ",checkfile
    time.sleep(10) 
    if os.path.exists(checkfile):
        found = 1

print "Average done "


############################  summarize the Q3/SOV information
# tag = 'abc'
args_str ="perl " + GLOBAL_PATH + "/lib/evaluation_dnss_prediction.pl -pred "  + predir +  " -out " + dnssdir + " -list " + test_list + " -tag " + tag
#print "Running "+ args_str
args = shlex.split(args_str)
pipe = subprocess.Popen(args, stdin=subprocess.PIPE)

scorefile=dnssdir+'/'+tag+'.score'


time.sleep(10) 
found = 0
while (found == 0):
    print "Checking file ",scorefile
    time.sleep(10) 
    if os.path.exists(scorefile):
        found = 1

print "Score saved to file ",scorefile

Q3_acc=0
SOV_acc=0
score_content=open(scorefile,'r').readlines() 
for i in xrange(len(score_content)):
    score_line = score_content[i].rstrip()
    if '#Average Q3 score'  in score_line: 
        score_tmp = score_line.split(':')
        Q3_acc = score_tmp[1]
        Q3_acc = Q3_acc.replace(" ", "")
    if '#Average Sov score'  in score_line: 
        score_tmp = score_line.split(':')
        SOV_acc = score_tmp[1]
        SOV_acc = SOV_acc.replace(" ", "")



acclog_dir=CV_dir
time_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
acclog_dir_temp = acclog_dir.split('/')
test_list_temp = test_list.split('/')
acc_history_out = "%s/%s.acc_history" % (acclog_dir, acclog_dir_temp[len(acclog_dir_temp)-1])
print '%s' % acc_history_out
chkdirs(acc_history_out)
if chkfiles(acc_history_out):
    print '####acc_file_exist,pass!'
    pass
else:
    print '####create_acc_file!'
    with open(acc_history_out, "w") as myfile:
        myfile.write("time\t netname\t dataset\t Accuracy\t Loss\t Q3\t SOV\n")

acc_history_content = "%s\t %s\t %s\t %s\t %s\n" % (time_str, model_prefix, test_list_temp[len(test_list_temp)-1],Q3_acc,SOV_acc)
with open(acc_history_out, "a") as myfile: myfile.write(acc_history_content)  

print "Q3 Accuracy %s" %(Q3_acc)
print "SOV Accuracy %s" %(SOV_acc)


 

