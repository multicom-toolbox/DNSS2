#!/bin/bash -l
#SBATCH -J  RCNNSS
#SBATCH -o RCNNSS-%j.out
#SBATCH --partition gpu3
#SBATCH --nodes=1
#SBATCH --ntasks=1         # leave at '1' unless using a MPI code
#SBATCH --cpus-per-task=1  # cores per task
#SBATCH --mem-per-cpu=10G  # memory per core (default is 1GB/core)
#SBATCH --time 2-00:00     # days-hours:minutes
#SBATCH --qos=normal
#SBATCH --account=general-gpu  # investors will replace this with their account name
#SBATCH --gres gpu:1

source /storage/hpc/scratch/zggc9/keras_theano/keras_virtual_env/bin/activate
echo "Training secondary structure"
module load R/R-3.3.1

export HDF5_USE_FILE_LOCKING=FALSE
temp_dir=$(pwd)
GLOBAL_PATH=${temp_dir%%DNSS2*}'DNSS2'
feature_dir=$GLOBAL_PATH/datasets/features_win1_with_atch
output_dir=$GLOBAL_PATH/output/model_train_FracNetSS_win1
acclog_dir=$GLOBAL_PATH/output/evaluate/model_cnnss_layer_compare

python $GLOBAL_PATH/models/RCNN1Dconv_ss/scripts/train_deepcovRCNN_ss_fast.py  15 35 5 nadam '3'  100 3  $feature_dir $output_dir 25
python $GLOBAL_PATH/lib/test_dnss.py $GLOBAL_PATH/datasets/adj_dncon-train.lst  15 35 5 nadam '3' $feature_dir $output_dir $acclog_dir 'deepss_1dRCNN' 'train' 25
python $GLOBAL_PATH/lib/test_dnss.py $GLOBAL_PATH/datasets/adj_dncon-test.lst  15 35 5 nadam '3' $feature_dir $output_dir $acclog_dir 'deepss_1dRCNN' 'test' 25
python $GLOBAL_PATH/lib/test_dnss.py $GLOBAL_PATH/datasets/casp9_10.lst  15 35 5 nadam '3' $feature_dir $output_dir $acclog_dir 'deepss_1dRCNN' 'evalu' 25
