#!/bin/bash -l
#SBATCH -J  INCEPSS
#SBATCH -o INCEPSS-%j.out
#SBATCH --partition gpu3
#SBATCH --nodes=1
#SBATCH --ntasks=1         # leave at '1' unless using a MPI code
#SBATCH --cpus-per-task=1  # cores per task
#SBATCH --mem-per-cpu=10G  # memory per core (default is 1GB/core)
#SBATCH --time 2-00:00     # days-hours:minutes
#SBATCH --qos=normal
#SBATCH --account=general-gpu  # investors will replace this with their account name
#SBATCH --gres gpu:1

source /storage/hpc/scratch/zggc9/keras_theano/keras_virtual_env/bin/activate
echo "Training secondary structure"
module load R/R-3.3.1

export HDF5_USE_FILE_LOCKING=FALSE
temp_dir=$(pwd)
GLOBAL_PATH=${temp_dir%%DNSS2*}'DNSS2'
feature_dir=$GLOBAL_PATH/datasets/features_win1_with_atch
output_dir=$GLOBAL_PATH/output/model_train_IncepSS_win1
acclog_dir=$GLOBAL_PATH/output/evaluate/model_cnnss_layer_compare
printf "$GLOBAL_PATH\n"

python $GLOBAL_PATH/models/Inception1Dconv_ss/scripts/train_deepcovInception_ss_fast.py  15 33 4 nadam '5'  100 3  $feature_dir $output_dir 32
python $GLOBAL_PATH/lib/test_dnss.py $GLOBAL_PATH/datasets/adj_dncon-train.lst  15 33 4 nadam '5' $feature_dir $output_dir $acclog_dir 'deepss_1dInception' 'train' 32
python $GLOBAL_PATH/lib/test_dnss.py $GLOBAL_PATH/datasets/adj_dncon-test.lst  15 33 4 nadam '5' $feature_dir $output_dir $acclog_dir 'deepss_1dInception' 'test' 32
python $GLOBAL_PATH/lib/test_dnss.py $GLOBAL_PATH/datasets/casp9_10.lst  15 33 4 nadam '5' $feature_dir $output_dir $acclog_dir 'deepss_1dInception' 'evalu' 32
