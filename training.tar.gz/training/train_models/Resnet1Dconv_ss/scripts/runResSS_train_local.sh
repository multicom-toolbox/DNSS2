export HDF5_USE_FILE_LOCKING=FALSE
GLOBAL_PATH=/mnt/data/zhiye/Python/DNSS2
feature_dir=$GLOBAL_PATH/datasets/features_win1_with_atch
output_dir=$GLOBAL_PATH/output/model_train_ResSS_win1
acclog_dir=$GLOBAL_PATH/output/evaluate/model_cnnss_layer_compare
if [ ! -d "$output_dir" ]
then
	echo "File not exists, create one"
	mkdir $output_dir
else
	echo "File exists"
fi

python $GLOBAL_PATH/models/Resnet1Dconv_ss/scripts/train_deepcovResnet_ss_fast.py  15 37 41 nadam '5'  100 3  $feature_dir $output_dir 25
python $GLOBAL_PATH/lib/test_dnss.py $GLOBAL_PATH/datasets/adj_dncon-train.lst  15 37 41 nadam '5' $feature_dir $output_dir $acclog_dir 'deepss_1dResnet' 'train' 25
python $GLOBAL_PATH/lib/test_dnss.py $GLOBAL_PATH/datasets/adj_dncon-test.lst  15 37 41 nadam '5' $feature_dir $output_dir $acclog_dir 'deepss_1dResnet' 'test' 25
python $GLOBAL_PATH/lib/test_dnss.py $GLOBAL_PATH/datasets/casp9_10.lst  15 37 41 nadam '5' $feature_dir $output_dir $acclog_dir 'deepss_1dResnet' 'evalu' 25
