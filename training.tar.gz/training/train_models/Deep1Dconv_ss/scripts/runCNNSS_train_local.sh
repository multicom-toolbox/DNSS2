export HDF5_USE_FILE_LOCKING=FALSE
GLOBAL_PATH=/mnt/data/zhiye/Python/DNSS2
feature_dir=$GLOBAL_PATH/datasets/features_win1_with_atch
output_dir=$GLOBAL_PATH/output/model_train_CNNSS_win1-2
acclog_dir=$GLOBAL_PATH/output/evaluate/model_cnnss_layer_compare
if [ ! -d "$output_dir" ]
then
	echo "File not exists, create one"
	mkdir $output_dir
else
	echo "File exists"
fi

python $GLOBAL_PATH/models/Deep1Dconv_ss/scripts/train_deepcov_ss_fast.py  15 40 5 nadam '6'  100 3  $feature_dir $output_dir 32

python $GLOBAL_PATH/lib/test_dnss.py $GLOBAL_PATH/datasets/new20181005/adj_dncon-train.lst  15 40 5 nadam '6' $feature_dir $output_dir $acclog_dir 'deepss_1dconv' 'train' 25

python $GLOBAL_PATH/lib/test_dnss.py $GLOBAL_PATH/datasets/new20181005/adj_dncon-test.lst  15 40 5 nadam '6' $feature_dir $output_dir $acclog_dir 'deepss_1dconv' 'test' 25

python $GLOBAL_PATH/lib/test_dnss.py $GLOBAL_PATH/datasets/new20181005/casp9_10.lst  15 40 5 nadam '6' $feature_dir $output_dir $acclog_dir 'deepss_1dconv' 'evalu' 25
